//
//  GamePlay.h
//  CutAndCross1
//
//  Created by Sumit Jain on 7/29/14.
//  Copyright (c) 2014 Impinge Solution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GamePlay : UIViewController

@property (nonatomic, strong) NSDictionary *dictionary;

@end
