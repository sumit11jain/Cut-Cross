//
//  AppDelegate.h
//  CutAndCross1
//
//  Created by Sumit Jain on 7/29/14.
//  Copyright (c) 2014 Impinge Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameCenter/GameCenterHelper.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, GameCenterHelperDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
