//
//  GamePlay.m
//  CutAndCross1
//
//  Created by Sumit Jain on 7/29/14.
//  Copyright (c) 2014 Impinge Solution. All rights reserved.
//

#import "GamePlay.h"

#import "GameBoard.h"

@interface GamePlay () {
    GameBoard *gameBoard;
    
    PlayerType selfPlayerType;
    
    uint32_t ourRandom;
    BOOL receivedRandom;
    __strong NSString *otherPlayerId;
}

@property (nonatomic, readwrite) NewGameState gameState;

@end

@implementation GamePlay

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc {
    gameBoard = nil;
}

- (void)viewDidLoad
{
    receivedRandom = NO;
    selfPlayerType = PlayerTypeNone;

    ourRandom = arc4random();
    [self setGameState:kNewGameStateWaitingForMatch];
    
//    gameBoard = [[GameBoard alloc] initWithDelegate:self andMaxCoordinatePoint:[[self.dictionary objectForKey:@"Max Point"] integerValue] inFrame:CGRectMake(0, 0, 320, 320)];
//    [gameBoard setBackgroundColor:[UIColor yellowColor]];
//    [gameBoard setPoints:[self.dictionary objectForKey:@"Points"]];
//    [self.view addSubview:gameBoard];
    
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

#pragma mark - send messages
- (void)sendData:(NSData*)data {
    NSError *error = nil;
    
    BOOL success = [[SharedGameCenterHelper currentMatch] sendDataToAllPlayers:data withDataMode:GKMatchSendDataReliable error:&error];
    if (!success) {
        NSLog(@"error sending message to player == %@", [error localizedDescription]);
        [self matchEnded];
    }
}

- (void)sendRandomNumber {
    MessageRandomNumber randNomessage;
    randNomessage.message.messageType = kMessageTypeRandomNumber;
    randNomessage.randomNumber = ourRandom;
    
    NSData *data = [NSData dataWithBytes:&randNomessage length:sizeof(MessageRandomNumber)];
    [self sendData:data];
}

- (void)sendGameBegin {
    MessageGameBegin message;
    message.message.messageType = kMessageTypeGameBegin;
    NSData *data = [NSData dataWithBytes:&message length:sizeof(MessageGameBegin)];
    [self sendData:data];
}

#pragma mark - GameCenter Receivers
- (void)matchStarted {
    if (receivedRandom) {
        [self setGameState:kNewGameStateWaitingForStart];
    } else {
        [self setGameState:kNewGameStateWaitingForRandomNumber];
    }
    
    [self sendRandomNumber];
    [self tryStartGame];
}

- (void)matchEnded {
    
}
- (void)match:(GKMatch*)match didReceiveData:(NSData *)data fromPlayer:(NSString *)playerID {
    // Store away other player ID for later
    if (otherPlayerId == nil) {
        otherPlayerId = playerID;
    }
    
    Message *message = (Message *) [data bytes];
    switch (message->messageType) {
        case kMessageTypeRandomNumber:
        {
            MessageRandomNumber * messageInit = (MessageRandomNumber *)message;
            NSLog(@"Received random number: %ud, ours %ud", messageInit->randomNumber, ourRandom);
            bool tie = false;
            
            if (messageInit->randomNumber == ourRandom) {
                NSLog(@"TIE!");
                tie = true;
                ourRandom = arc4random();
                [self sendRandomNumber];
            } else if (ourRandom > messageInit->randomNumber) {
                NSLog(@"We are white players");
                selfPlayerType = PlayerTypeWhite;
//                isPlayer1 = YES;
            } else {
                NSLog(@"We are black players");
                selfPlayerType = PlayerTypeBlack;
//                isPlayer1 = NO;
            }
            
            if (!tie) {
                receivedRandom = YES;
                if (self.gameState == kNewGameStateWaitingForRandomNumber) {
                    [self setGameState:kNewGameStateWaitingForStart];
                }
                [self tryStartGame];        
            }
        }
            break;
            
        case kMessageTypeGameBegin:
        {
            [self setGameState:kNewGameStateActive];
        }
            break;
            
        case kMessageTypeMove:
        {
            [gameBoard moveOpponentWithMoveMessage:(MessageMove *)message];
        }
            
            break;
            
        case kMessageTypeGameOver:
        {
            
        }
            
            break;
            
    }
}

- (void)tryStartGame {
    
    if (self.gameState == kNewGameStateWaitingForStart) {
        [self setGameState:kNewGameStateActive];
        [self sendGameBegin];
    }
}

- (void)setGameState:(NewGameState)state {
    
    _gameState = state;
    if (_gameState == kNewGameStateWaitingForMatch) {
//        [debugLabel setText:@"Waiting for match"];
    } else if (_gameState == kNewGameStateWaitingForRandomNumber) {
//        [debugLabel setText:@"Waiting for rand #"];
    } else if (_gameState == kNewGameStateWaitingForStart) {
//        [debugLabel setText:@"Waiting for start"];
    } else if (_gameState == kNewGameStateActive) {
//        [debugLabel setText:@"Active"];
    } else if (_gameState == kNewGameStateDone) {
//        [debugLabel setText:@"Done"];
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
