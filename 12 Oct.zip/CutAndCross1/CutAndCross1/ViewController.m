//
//  ViewController.m
//  CutAndCross1
//
//  Created by Sumit Jain on 7/29/14.
//  Copyright (c) 2014 Impinge Solution. All rights reserved.
//

#import "ViewController.h"
#import "GamePlay.h"

@interface ViewController () {
    NSArray *levelsInfo;
}

@end

@implementation ViewController

- (void)dealloc {
    levelsInfo = nil;
}

- (void)viewDidLoad
{
    NSArray *filePaths = [[NSBundle mainBundle] pathsForResourcesOfType:@"plist" inDirectory:@"Levels Info"];
    
    NSMutableArray *info = [NSMutableArray arrayWithCapacity:0];
    
    NSDictionary *dictionary;
    for (NSString *path in filePaths) {
        dictionary = [NSDictionary dictionaryWithContentsOfFile:path];
        [info addObject:dictionary];
        dictionary = nil;
    }
    
    levelsInfo = [[NSArray alloc] initWithArray:info];
    info = nil;
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [levelsInfo count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *ci = @"ci";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ci];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ci];
    }
    
    cell.textLabel.text = nil;
    cell.textLabel.text = levelsInfo[indexPath.row][@"Name"];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    GamePlay *gp = (GamePlay*)[[UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:@"GamePlay"];
    [gp setLevelTOPlay:indexPath.row+1];
    [gp setDictionary:levelsInfo[indexPath.row]];
    [self.navigationController pushViewController:gp animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
