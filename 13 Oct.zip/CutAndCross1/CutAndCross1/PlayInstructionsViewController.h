//
//  HowPlayViewController.h
//  CutAndCross1
//
//  Created by Sumit Jain on 10/13/14.
//  Copyright (c) 2014 Impinge Solution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayInstructionsViewController : UIViewController

@end
