//
//  PlayerTypeInformation.h
//  CutAndCross1
//
//  Created by Impinge Sumit Jain on 28/08/14.
//  Copyright (c) 2014 Impinge Solution. All rights reserved.
//

typedef enum {
    PlayerTypeNone = 0,
    PlayerTypeWhite,
    PlayerTypeBlack
}PlayerType;

typedef enum {
    GameStateSelectedPointNoneWithWhiteTurn = 0,
    GameStateSelectedPointNoneWithBlackTurn,
    GameStateSelectedPointToMove,
//    GameStateSelectedPointWhite,
//    GameStateSelectedPointBlack,
    GameStateMovingPiece
}GameState;